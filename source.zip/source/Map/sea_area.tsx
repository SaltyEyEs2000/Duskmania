<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="sea_area" tilewidth="9088" tileheight="4221" tilecount="4" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="9088" height="4221" source="../../sea_area.png"/>
 </tile>
 <tile id="1">
  <image width="9088" height="4221" source="../../border.png"/>
 </tile>
 <tile id="2">
  <image width="9088" height="4221" source="../../game_worldmap1.png"/>
 </tile>
 <tile id="3">
  <image width="88" height="102" source="../../Filter.png"/>
 </tile>
</tileset>
